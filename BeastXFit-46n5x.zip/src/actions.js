import { HttpError } from 'wasp/server'

export const addFood = async (args, context) => {
  if (!context.user) { throw new HttpError(401); }

  const newFood = await context.entities.Food.create({
    data: {
      name: args.name,
      calories: args.calories,
      userId: context.user.id
    }
  });

  return newFood;
}

export const addExercise = async ({ name, description, imageUrl }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const newExercise = await context.entities.Exercise.create({
    data: {
      name,
      description,
      imageUrl,
      userId: context.user.id
    }
  });

  return newExercise;
}

export const createPlan = async ({ name, description, isPaid }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const newPlan = await context.entities.Plan.create({
    data: {
      name,
      description,
      isPaid,
      user: { connect: { id: context.user.id } }
    }
  });

  return newPlan;
}
