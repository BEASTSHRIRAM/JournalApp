import React, { useState } from 'react';
import { useQuery, useAction, getExercises, addExercise } from 'wasp/client/operations';

const ExercisePage = () => {
  const { data: exercises, isLoading, error } = useQuery(getExercises);
  const addExerciseFn = useAction(addExercise);
  const [newExercise, setNewExercise] = useState({ name: '', description: '', imageUrl: '' });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleAddExercise = () => {
    addExerciseFn(newExercise);
    setNewExercise({ name: '', description: '', imageUrl: '' });
  };

  return (
    <div className='p-6'>
      <h1 className='text-2xl font-bold mb-4'>Exercises</h1>
      <div className='mb-6'>
        <input
          type='text'
          placeholder='Exercise Name'
          value={newExercise.name}
          onChange={e => setNewExercise({ ...newExercise, name: e.target.value })}
          className='border rounded p-2 mb-2 w-full'
        />
        <input
          type='text'
          placeholder='Description'
          value={newExercise.description}
          onChange={e => setNewExercise({ ...newExercise, description: e.target.value })}
          className='border rounded p-2 mb-2 w-full'
        />
        <input
          type='text'
          placeholder='Image URL'
          value={newExercise.imageUrl}
          onChange={e => setNewExercise({ ...newExercise, imageUrl: e.target.value })}
          className='border rounded p-2 mb-2 w-full'
        />
        <button
          onClick={handleAddExercise}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          Add Exercise
        </button>
      </div>
      <div>
        {exercises.map(exercise => (
          <div key={exercise.id} className='mb-4 p-4 rounded-lg shadow-md bg-white'>
            <h2 className='text-xl font-bold'>{exercise.name}</h2>
            <p>{exercise.description}</p>
            {exercise.imageUrl && <img src={exercise.imageUrl} alt={exercise.name} className='w-full h-64 object-cover mt-2 rounded'/>}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExercisePage;
