import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { getFoods, getExercises, getPlans } from 'wasp/client/operations';

const HomePage = () => {
  const { data: foods, isLoading: loadingFoods, error: errorFoods } = useQuery(getFoods);
  const { data: exercises, isLoading: loadingExercises, error: errorExercises } = useQuery(getExercises);
  const { data: plans, isLoading: loadingPlans, error: errorPlans } = useQuery(getPlans);

  if (loadingFoods || loadingExercises || loadingPlans) return 'Loading...';
  if (errorFoods || errorExercises || errorPlans) return 'Error occurred.';

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Welcome to BeastXFit</h1>
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Your Foods</h2>
        <ul className="list-disc pl-5">
          {foods.map(food => (
            <li key={food.id}>{food.name} - {food.calories} calories</li>
          ))}
        </ul>
      </section>
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Your Exercises</h2>
        <ul className="list-disc pl-5">
          {exercises.map(exercise => (
            <li key={exercise.id}>{exercise.name}</li>
          ))}
        </ul>
      </section>
      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Your Plans</h2>
        <ul className="list-disc pl-5">
          {plans.map(plan => (
            <li key={plan.id}>{plan.name} - {plan.isPaid ? 'Paid' : 'Free'}</li>
          ))}
        </ul>
      </section>
    </div>
  );
}

export default HomePage;
