import React, { useState } from 'react';
import { useQuery, useAction, getFoods, addFood } from 'wasp/client/operations';

const FoodTrackerPage = () => {
  const { data: foods, isLoading, error } = useQuery(getFoods);
  const addFoodFn = useAction(addFood);
  const [foodName, setFoodName] = useState('');
  const [calories, setCalories] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleAddFood = () => {
    if (foodName && calories) {
      addFoodFn({ name: foodName, calories: parseInt(calories) });
      setFoodName('');
      setCalories('');
    }
  };

  return (
    <div className='p-4'>
      <div className='flex gap-x-4 mb-4'>
        <input
          type='text'
          placeholder='Food Name'
          className='px-1 py-2 border rounded text-lg'
          value={foodName}
          onChange={(e) => setFoodName(e.target.value)}
        />
        <input
          type='number'
          placeholder='Calories'
          className='px-1 py-2 border rounded text-lg'
          value={calories}
          onChange={(e) => setCalories(e.target.value)}
        />
        <button
          onClick={handleAddFood}
          className='bg-blue-500 hover:bg-blue-700 px-4 py-2 text-white font-bold rounded'
        >
          Add Food
        </button>
      </div>
      <div>
        {foods && foods.map((food) => (
          <div
            key={food.id}
            className='flex justify-between items-center py-2 px-2 border-b'
          >
            <p>{food.name}</p>
            <p>{food.calories} kcal</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FoodTrackerPage;
