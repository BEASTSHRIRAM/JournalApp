import { HttpError } from 'wasp/server'

export const getFoods = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Food.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getExercises = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Exercise.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getPlans = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Plan.findMany({
    where: { userId: context.user.id }
  })
}
